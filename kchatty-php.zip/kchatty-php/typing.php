<?php
require('util.inc.php');

session_id(urlencode($_GET['sid']));
session_readonly();

if (!isset($_SESSION['typingUsers'])) {
	sleep(1);
	http_response_code(218);
	exit();
}

$userCount = count($_SESSION['typingUsers']);

$i = 0;
for (;$i < 100 && !connection_aborted(); $i++) {
	session_readonly();
	
	$cnt = count($_SESSION['typingUsers']);
	if ($cnt != $userCount) {
		header('content-type: text/html');
		if ($cnt > 0) {
			echo 'Users typing: ' . $cnt;
		}
		break;
	}
	
	// 100 ms
	usleep(1000000 / 100); 
}
if ($i == 100) http_response_code(218);
?>
