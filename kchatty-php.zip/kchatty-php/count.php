<?php
require('util.inc.php');

session_id(urlencode($_GET['sid']));
session_readonly();

if (!isset($_SESSION['users'])) {
	sleep(1);
	http_response_code(218);
	exit();
}

if ($_GET['first'] == "1") {
	header('content-type: text/html');
	echo '#fff:Users in room: ' . count($_SESSION['users']);
	exit();
}

$userCount = count($_SESSION['users']);

$i = 0;
for (;$i < 100 && !connection_aborted(); $i++) {
	session_readonly();
	
	$cnt = count($_SESSION['users']);
	if ($cnt != $userCount) {
		header('content-type: text/html');
		echo '#fff:Users in room: ' . $cnt;
		break;
	}
	
	// 100 ms
	usleep(1000000 / 100); 
}
if ($i == 100) http_response_code(218);
?>
