<?php
require('util.inc.php');

session_id(urlencode($_GET['sid']));
session_start();

$userId = userId();
if ($_GET['val'] == "1") {
	$_SESSION['typingUsers'][$userId] = true;
} else {
	unset($_SESSION['typingUsers'][$userId]);
}
?>
