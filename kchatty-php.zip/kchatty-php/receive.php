<?php
require('util.inc.php');

session_id(urlencode($_GET['sid']));

$userId = userId();

$framestamp = parseInt($_GET['framestamp']);

$i = 0;
for (;$i < 100 && !connection_aborted(); $i++) {
	session_start();
	$_SESSION['users'][$userId] = microtime(true);

	// kick away users every x seconds
	$start = microtime(true);
	foreach ($_SESSION['users'] as $uid => $t) {
		if ($start - $t > 2.0) {
			unset($_SESSION['users'][$uid]);
			unset($_SESSION['typingUsers'][$uid]);
		} 
	}
	session_write_close();
	
	if (isset($_SESSION['line'])) {
		$frame = $_SESSION['line'];
		$diff = $frame->framestamp - $framestamp;
		if ($diff > 0) {
			header('content-type: text/html');
			header('framestamp: ' . $frame->framestamp);
			echo $frame->data;
			break;
		} 
	}
	
	// 100 ms
	usleep(1000000 / 100); 
}
if ($i == 100) http_response_code(218);
?>
