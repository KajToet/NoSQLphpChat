<?php
require('util.inc.php');


session_id(urlencode($_GET['sid']));
session_start();

$fs = 1;
if (isset($_SESSION['line'])) {
	$frame = $_SESSION['line'];
	$fs = $frame->framestamp + 1;
}

if (isset($_GET['data'])) {
	$frame = new Frame();
	$frame->framestamp = $fs;
	$frame->data = color() . ':' . htmlspecialchars($_GET['data']);
	$_SESSION['line'] = $frame;
} 

echo $fs;
?>
